using System;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;

namespace FlexAmerica.Class {

    public class Template : DBObject {

        #region Enum
        private enum DataField {
            Id = 0,
            //Enum Values
        }
        #endregion 

        #region Private Properties
        //Private Properties
        #endregion

        #region Public Accessors
        //Public Accessors
        #endregion

        #region Constructors
        public static Template GetById(int id) {

            string procedureName = "Template_Get_By_Id";
            string connectionString = Utility.GetConnectionString();

            SqlDataReader dR = null;
            try {
                SqlParameter[] spParams = SqlHelperParameterCache.GetSpParameterSet(connectionString, procedureName);
                spParams[0].Value = id;
                dR = SqlHelper.ExecuteReader(connectionString, CommandType.StoredProcedure, procedureName, spParams);

                return dR.Read() ? Template.Fill(dR) : null;
            }
            finally {
                dR.Close();
            }
        }
        #endregion 


        #region Methods
        internal static Template Fill(System.Data.SqlClient.SqlDataReader dR) {
            Template template = new Template();

            template.Id = Class.Utility.ConvertNullToInt(dR[(int)DataField.Id]);

            return template;
        } 
        
        public override void Save(int userId) {
            string procedureName = "Template_Save";
            base.TaskName = procedureName;
            base.Save(userId);

            string connectionString = Utility.GetConnectionString();

            SqlParameter[] spParams = SqlHelperParameterCache.GetSpParameterSet(connectionString, procedureName);
            spParams[0].Value = id;

            SqlHelper.ExecuteNonQuery(connectionString, CommandType.StoredProcedure, procedureName, spParams);
        }

        public override bool Validate() {
            return true;
        }
        #endregion 

       

    }


}
